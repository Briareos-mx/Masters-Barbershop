<?php
session_start();
require_once ('conecta.php');
//serv:serv, barb:barb
$serv = $_POST['serv'];
$barb = $_POST['barb'];
$date = $_POST['date'];
$hour = $_POST['hour'];//diez
$user = $_SESSION['usuario'];

$sqlba = 'SELECT `b_cons` FROM `barberos` WHERE `b_clave`= "'.$barb.'"';
$consultba = mysqli_query($con,$sqlba);
$rowba = mysqli_fetch_assoc($consultba);
$b_cons = $rowba['b_cons'];

$sqlse = 'SELECT `s_cons` FROM `servicios` WHERE `s_key` = "'.$serv.'"';
$consultse = mysqli_query($con,$sqlse);
$rowse = mysqli_fetch_assoc($consultse);
$s_cons = $rowse['s_cons'];


$fecha = date_create_from_format('j M, Y', $date);//date('Y-m-d', strtotime($datep));
$buscafecha = date_format($fecha, 'Y-m-d');
$buscadia = date('w', strtotime($buscafecha));
$dkey = date_format($fecha, 'ymd');//date('ymd', strtotime($buscafecha));

//echo 'BUSCAFECHA: '.$buscafecha.'<br>';
//echo 'BUSCADIA: '.$buscadia.'<br>';
//echo 'FECHA: '.$dkey.'<br>';

  if ($hour == 'ocho') {
    $hr = 8;
  } else if ($hour == 'ocho5') {
    $hr = 85;
  } else if ($hour == 'nueve') {
    $hr = 9;
  } else if ($hour == 'nueve5') {
    $hr = 95;
  } else if ($hour == 'diez') {
    $hr = 10;
  } else if ($hour == 'diez5') {
    $hr = 105;
  } else if ($hour == 'once') {
    $hr = 11;
  } else if ($hour == 'once5') {
    $hr = 115;
  } else if ($hour == 'doce') {
    $hr = 12;
  } else if ($hour == 'doce5') {
    $hr = 125;
  } else if ($hour == 'trece') {
    $hr = 13;
  } else if ($hour == 'trece5') {
    $hr = 135;
  } else if ($hour == 'catorce') {
    $hr = 14;
  } else if ($hour == 'catorce5') {
    $hr = 145;
  } else if ($hour == 'quince') {
    $hr = 15;
  } else if ($hour == 'quince5') {
    $hr = 155;
  } else if ($hour == 'dieciseis') {
    $hr = 16;
  } else if ($hour == 'dieciseis5') {
    $hr = 165;
  } else if ($hour == 'diecisiete') {
    $hr = 17;
  } else if ($hour == 'diecisiete5') {
    $hr = 175;
  }
$servnum = $dkey.$b_cons.$s_cons.$hr;
$sqls = 'SELECT * FROM `calendar` WHERE `c_barber`="'.$barb.'" AND `c_day`="'.$buscafecha.'"';
$consults = mysqli_query($con,$sqls);
$nums = mysqli_num_rows($consults);
if ($nums < 1) {
	if ($hour == 'ocho') {
    $c_eight = $servnum;
  } else {
    $c_eight = 0;
  }
  if ($hour == 'ocho5') {
    $c_eight_half = $servnum;
  } else {
    $c_eight_half = 0;
  }
  if ($hour == 'nueve') {
    $c_nine = $servnum;
  } else {
    $c_nine = 0;
  }
  if ($hour == 'nueve5') {
    $c_nine_half = $servnum;
  } else {
    $c_nine_half = 0;
  }
  if ($hour == 'diez') {
    $c_ten = $servnum;
  } else {
    $c_ten = 0;
  }
  if ($hour == 'diez5') {
    $c_ten_half = $servnum;
  } else {
    $c_ten_half = 0;
  }
  if ($hour == 'once') {
    $c_eleven = $servnum;
  } else {
    $c_eleven = 0;
  }
  if ($hour == 'once5') {
    $c_eleven_half = $servnum;
  } else {
    $c_eleven_half = 0;
  }
  if ($hour == 'doce') {
    $c_twelve = $servnum;
  } else {
    $c_twelve = 0;
  }
  if ($hour == 'doce5') {
    $c_twelve_half = $servnum;
  } else {
    $c_twelve_half = 0;
  }
  if ($hour == 'trece') {
    $c_thirteen = $servnum;
  } else {
    $c_thirteen = 0;
  }
  if ($hour == 'trece5') {
    $c_thirteen_half = $servnum;
  } else {
    $c_thirteen_half = 0;
  }
  if ($hour == 'catorce') {
    $c_fourteen = $servnum;
  } else {
    $c_fourteen = 0;
  }
  if ($hour == 'catorce5') {
    $c_fourteen_half = $servnum;
  } else {
    $c_fourteen_half = 0;
  }
  if ($hour == 'quince') {
    $c_fifteen = $servnum;
  } else {
    $c_fifteen = 0;
  }
  if ($hour == 'quince5') {
    $c_fifteen_half = $servnum;
  } else {
    $c_fifteen_half = 0;
  }
  if ($hour == 'dieciseis') {
    $c_sixteen = $servnum;
  } else {
    $c_sixteen = 0;
  }
  if ($hour == 'dieciseis5') {
    $c_sixteen_half = $servnum;
  } else {
    $c_sixteen_half = 0;
  }
  if ($hour == 'diecisiete') {
    $c_seventeen = $servnum;
  } else {
    $c_seventeen = 0;
  }
  if ($hour == 'diecisiete5') {
    $c_seventeen_half = $servnum;
  } else {
    $c_seventeen_half = 0;
  }
	$sqli = 'INSERT INTO `calendar`(`c_barber`, `c_eight`, `c_eight_half`, `c_nine`, `c_nine_half`, `c_ten`, `c_ten_half`, `c_eleven`, `c_eleven_half`, `c_twelve`, `c_twelve_half`, `c_thirteen`, `c_thirteen_half`, `c_fourteen`, `c_fourteen_half`, `c_fifteen`, `c_fifteen_half`, `c_sixteen`, `c_sixteen_half`, `c_seventeen`, `c_seventeen_half`, `c_day`) VALUES ("'.$barb.'", "'.$c_eight.'", "'.$c_eight_half.'", "'.$c_nine.'", "'.$c_nine_half.'", "'.$c_ten.'", "'.$c_ten_half.'", "'.$c_eleven.'", "'.$c_eleven_half.'", "'.$c_twelve.'", "'.$c_twelve_half.'", "'.$c_thirteen.'", "'.$c_thirteen_half.'", "'.$c_fourteen.'", "'.$c_fourteen_half.'", "'.$c_fifteen.'", "'.$c_fifteen_half.'", "'.$c_sixteen.'", "'.$c_sixteen_half.'", "'.$c_seventeen.'", "'.$c_seventeen_half.'","'.$buscafecha.'")';
	$consulti = mysqli_query($con,$sqli);
	$numi = mysqli_affected_rows($con);
	if ($numi > 0) {
		$state = 'activo';
		$sqlserv = 'INSERT INTO `servicio`(`sr_number`, `sr_cliente`, `sr_servicio`, `sr_barbero`, `sr_fecha`, `sr_hora`, `sr_state`) VALUES ("'.$servnum.'", "'.$user.'", "'.$serv.'", "'.$barb.'", "'.$buscafecha.'", "'.$hour.'", "'.$state.'")';
		$consultserv = mysqli_query($con,$sqlserv);
		$numserv = mysqli_affected_rows($con); 
		if ($numserv >0) {
			echo ('INCERT_SERV');
		} else {
      echo('ERROR1A');
    }
	} else {
		echo('ERROR1');
	}
} else {
	$rows = mysqli_fetch_assoc($consults);
	$x_barber = $rows['c_barber'];
	$x_eight = $rows['c_eight'];
	$x_eight_half = $rows['c_eight_half'];
	$x_nine = $rows['c_nine'];
	$x_nine_half = $rows['c_nine_half'];
	$x_ten = $rows['c_ten'];
	$x_ten_half = $rows['c_ten_half'];
	$x_eleven = $rows['c_eleven'];
	$x_eleven_half = $rows['c_eleven_half'];
	$x_twelve = $rows['c_twelve'];
	$x_twelve_half = $rows['c_twelve_half'];
	$x_thirteen = $rows['c_thirteen'];
	$x_thirteen_half = $rows['c_thirteen_half'];
	$x_fourteen = $rows['c_fourteen'];
	$x_fourteen_half = $rows['c_fourteen_half'];
	$x_fifteen = $rows['c_fifteen'];
	$x_fifteen_half = $rows['c_fifteen_half'];
	$x_sixteen = $rows['c_sixteen'];
	$x_sixteen_half = $rows['c_sixteen_half'];
	$x_seventeen = $rows['c_seventeen'];
	$x_seventeen_half = $rows['c_seventeen_half'];
	$x_day = $rows['c_day'];
	
	if ($hour == 'ocho') {
    $c_eight = $servnum;
  } else {
    $c_eight = $x_eight;
  }
  if ($hour == 'ocho5') {
    $c_eight_half = $servnum;
  } else {
    $c_eight_half = $x_eight_half;
  }
  if ($hour == 'nueve') {
    $c_nine = $servnum;
  } else {
    $c_nine = $x_nine;
  }
  if ($hour == 'nueve5') {
    $c_nine_half = $servnum;
  } else {
    $c_nine_half = $x_nine_half;
  }
  if ($hour == 'diez') {
    $c_ten = $servnum;
  } else {
    $c_ten = $x_ten;
  }
  if ($hour == 'diez5') {
    $c_ten_half = $servnum;
  } else {
    $c_ten_half = $x_ten_half;
  }
  if ($hour == 'once') {
    $c_eleven = $servnum;
  } else {
    $c_eleven = $x_eleven;
  }
  if ($hour == 'once5') {
    $c_eleven_half = $servnum;
  } else {
    $c_eleven_half = $x_eleven_half;
  }
  if ($hour == 'doce') {
    $c_twelve = $servnum;
  } else {
    $c_twelve = $x_twelve;
  }
  if ($hour == 'doce5') {
    $c_twelve_half = $servnum;
  } else {
    $c_twelve_half = $x_twelve_half;
  }
  if ($hour == 'trece') {
    $c_thirteen = $servnum;
  } else {
    $c_thirteen = $x_thirteen;
  }
  if ($hour == 'trece5') {
    $c_thirteen_half = $servnum;
  } else {
    $c_thirteen_half = $x_thirteen_half;
  }
  if ($hour == 'catorce') {
    $c_fourteen = $servnum;
  } else {
    $c_fourteen = $x_fourteen;
  }
  if ($hour == 'catorce5') {
    $c_fourteen_half = $servnum;
  } else {
    $c_fourteen_half = $x_fourteen_half;
  }
  if ($hour == 'quince') {
    $c_fifteen = $servnum;
  } else {
    $c_fifteen = $x_fifteen;
  }
  if ($hour == 'quince5') {
    $c_fifteen_half = $servnum;
  } else {
    $c_fifteen_half = $x_fifteen_half;
  }
  if ($hour == 'dieciseis') {
    $c_sixteen = $servnum;
  } else {
    $c_sixteen = $x_sixteen;
  }
  if ($hour == 'dieciseis5') {
    $c_sixteen_half = $servnum;
  } else {
    $c_sixteen_half = $x_sixteen_half;
  }
  if ($hour == 'diecisiete') {
    $c_seventeen = $servnum;
  } else {
    $c_seventeen = $x_seventeen;
  }
  if ($hour == 'diecisiete5') {
    $c_seventeen_half = $servnum;
  } else {
    $c_seventeen_half = $x_seventeen_half;
  }
	$sqlu = 'UPDATE `calendar` SET `c_eight`="'.$c_eight.'", `c_eight_half`="'.$c_eight_half.'", `c_nine`="'.$c_nine.'", `c_nine_half`="'.$c_nine_half.'", `c_ten`="'.$c_ten.'", `c_ten_half`="'.$c_ten_half.'", `c_eleven`="'.$c_eleven.'", `c_eleven_half`="'.$c_eleven_half.'",`c_twelve`="'.$c_twelve.'", `c_twelve_half`="'.$c_twelve_half.'", `c_thirteen`="'.$c_thirteen.'", `c_thirteen_half`="'.$c_thirteen_half.'", `c_fourteen`="'.$c_fourteen.'", `c_fourteen_half`="'.$c_fourteen_half.'", `c_fifteen`="'.$c_fifteen.'", `c_fifteen_half`="'.$c_fifteen_half.'", `c_sixteen`="'.$c_sixteen_half.'", `c_sixteen_half`="'.$c_sixteen_half.'", `c_seventeen`="'.$c_seventeen.'", `c_seventeen_half`="'.$c_seventeen_half.'" WHERE `c_barber` ="'.$barb.'" AND `c_day`="'.$buscafecha.'"';
	$consultu = mysqli_query($con,$sqlu);
	$numu = mysqli_affected_rows($con);
	if ($numu > 0) {
		$state = 'activo';
		$sqlserv = 'INSERT INTO `servicio`(`sr_number`, `sr_cliente`, `sr_servicio`, `sr_barbero`, `sr_fecha`, `sr_hora`, `sr_state`) VALUES ("'.$servnum.'", "'.$user.'", "'.$serv.'", "'.$barb.'", "'.$buscafecha.'", "'.$hour.'", "'.$state.'")';
		$consultserv = mysqli_query($con,$sqlserv);
		$numserv = mysqli_affected_rows($con); 
		if ($numserv >0) {
			echo ('ACTUAL_SERV');
		} else {
      echo('ERROR2A');
    }
	} else {
		echo('ERROR2');
	}
}
?>