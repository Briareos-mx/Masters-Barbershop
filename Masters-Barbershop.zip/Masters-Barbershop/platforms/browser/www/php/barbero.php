<?php
session_start();
require_once ('conecta.php');
$barbp = $_POST['barb'];
$data = [];
if ($barbp == 'available') {
	$sql = 'SELECT * FROM `barberos` WHERE `b_clave`!= "'.$barbp.'"';
  $consulta = mysqli_query($con,$sql);
  while($row = mysqli_fetch_assoc($consulta)){
    $b_clave = $row['b_clave'];
    $b_name = $row['b_name'];
    $b_picture = $row['b_picture'];
    $b_color = $row['b_color'];
    $b_color_code = $row['b_color_code'];
    $rowEmp = array('b_clave' => $b_clave, 'b_name' => $b_name, 'b_picture' => $b_picture, 'b_color' => $b_color, 'b_color_code' => $b_color_code);
    $data[] = array_map('htmlentities', $rowEmp);
	}
} else {
	$sql = 'SELECT * FROM `barberos` WHERE `b_clave`="'.$barbp.'"';
  $consulta = mysqli_query($con,$sql);
  $row = mysqli_fetch_assoc($consulta);
  $b_clave = $row['b_clave'];
  $b_name = $row['b_name'];
  $b_picture = $row['b_picture'];
  $b_color = $row['b_color'];
  $b_color_code = $row['b_color_code'];
  $rowEmp = array('b_clave' => $b_clave, 'b_name' => $b_name, 'b_picture' => $b_picture, 'b_color' => $b_color, 'b_color_code' => $b_color_code);
  $data[] = array_map('htmlentities', $rowEmp);
}
echo json_encode($data);
?>