<?php
session_start();
require_once ('conecta.php');
//serv:serv, barb:barb
$serv = $_POST['serv'];
$barb = $_POST['barb'];
$data = [];

$sql = 'SELECT * FROM `barberos` WHERE `b_clave` = "'.$barb.'"';
$consulta = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($consulta);
$b_clave = $row['b_clave'];
$b_name = $row['b_name'];
$b_picture = $row['b_picture'];
$b_color = $row['b_color'];
$b_color_code = $row['b_color_code'];

$sql2 = 'SELECT * FROM `servicios` WHERE `s_key` ="'.$serv.'"';
$consulta2 = mysqli_query($con,$sql2);
$row2 = mysqli_fetch_assoc($consulta2);
$s_key = $row2['s_key'];
$s_name = $row2['s_name'];
$s_picture = $row2['s_picture'];
$s_color = $row2['s_color'];
$s_color_code = $row2['s_color_code'];

$rowEmp = array('b_clave' => $b_clave, 'b_name' => $b_name, 'b_picture' => $b_picture, 'b_color' => $b_color, 'b_color_code' => $b_color_code, 's_key' => $s_key, 's_name' => $s_name, 's_picture' => $s_picture, 's_color' => $s_color, 's_color_code' => $s_color_code);
$data[] = array_map('htmlentities', $rowEmp);

echo json_encode($data);
?>