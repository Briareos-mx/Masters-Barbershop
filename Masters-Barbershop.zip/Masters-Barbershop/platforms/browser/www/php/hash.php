<?php
require_once ('conecta.php');

$sql = 'SELECT * FROM `registro`';
$consulta = mysqli_query($con, $sql);
while($row = mysqli_fetch_assoc($consulta)) {
	$cont		= $row['cont'];
	$usr	= $row['usr'];
	$hashpass = password_hash($cont, PASSWORD_DEFAULT);
	$sqlUp	= 'UPDATE `registro` SET `pass`="'.$hashpass.'" WHERE `usr`="'.$usr.'"';
	mysqli_query($con, $sqlUp);
	echo 'Correo: '.$usr.' Contraseña: '.$cont.' Hash: '.$hashpass.'<br>';
}
?>