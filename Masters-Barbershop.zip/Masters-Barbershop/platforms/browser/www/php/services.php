<?php
session_start();
require_once ('conecta.php');
$data = [];
$sql = 'SELECT * FROM `servicios`';
$consulta = mysqli_query($con,$sql);
while($row = mysqli_fetch_assoc($consulta)) {
  $s_key = $row['s_key'];
  $s_name = $row['s_name'];
  $s_picture = $row['s_picture'];
	$s_color = $row['s_color'];
  $rowEmp = array('s_key' => $s_key, 's_name' => $s_name, 's_picture' => $s_picture, 's_color' => $s_color);
  $data[] = array_map('htmlentities', $rowEmp);
}
echo json_encode($data);
?>