<?php
session_start();
require_once ('conecta.php');
$usr = $_SESSION["usuario"];
$sql = 'SELECT * FROM `registro` WHERE `usr`= "'.$usr.'"';
$consulta = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($consulta);
$clave = $row['clave'];
$nombre = $row['nombre'];
$apellido = $row['apellido'];
//$telefono = $row['telefono'];
$nom_comp = $nombre.' '.$apellido;
$_SESSION['nom_comp'] = $nom_comp;
//$_SESSION['telefono'] = $telefono;
$rowEmp = array('nom_comp' => $nom_comp);
$data[] = array_map('htmlentities', $rowEmp);
echo json_encode($data);
?>