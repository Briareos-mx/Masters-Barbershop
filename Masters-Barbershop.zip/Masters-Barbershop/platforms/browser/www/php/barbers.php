<?php
session_start();
require_once ('conecta.php');
$data = [];
$sql = 'SELECT * FROM `barberos` ORDER BY `b_cons` ASC';
$consulta = mysqli_query($con,$sql);
while($row = mysqli_fetch_assoc($consulta)) {
  $b_clave = $row['b_clave'];
  $b_name = $row['b_name'];
  $b_picture = $row['b_picture'];
	$b_color = $row['b_color'];
  $rowEmp = array('b_clave' => $b_clave, 'b_name' => $b_name, 'b_picture' => $b_picture, 'b_color' => $b_color);
  $data[] = array_map('htmlentities', $rowEmp);
}
echo json_encode($data);
?>