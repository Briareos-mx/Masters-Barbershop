<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'Exception.php';
require 'PHPMailer.php';
require 'SMTP.php';
date_default_timezone_set('America/Mexico_City');
setlocale(LC_ALL,"es_MX.UTF-8");

$fecha = strftime("%Y-%m-%d");
$hoy = strftime("%y%m%d");

session_start();
require_once ('conecta.php');
$hoy = date("Y-m-d");
//usr:elusr, pass:elpass, confirm:elconfirm, name:name, last:ellast, phone:elphone
$usr = 'briareos_mx@yahoo.com.mx';//$_POST["usr"];//email direction//
$pass = 'hastaquetruene';//$_POST["pass"];//
$name = 'Briareos';//$_POST["name"];
$last = 'Ugalde';//$_POST["last"];
$phone = '1234567890';//$_POST["phone"];
$hashpass = password_hash($pass, PASSWORD_DEFAULT);

$sql = 'INSERT INTO `registro`(`pass`, `usr`, `nombre`, `apellido`, `telefono`, `registro`, `fecha`, `cumple`, `cont`, `activo`, `suspended`) VALUES ("'.$hashpass.'", "'.$usr.'", "'.$name.'", "'.$last.'", "'.$phone.'", "0", "'.$hoy.'", "'.$hoy.'", "'.$pass.'", "0", "0")';
$consulta = mysqli_query($con,$sql);
$total = mysqli_affected_rows($con);
if($total < 1){
    echo 'NoData';
} else {
	//echo 'exito';
	//SEND CHECK MAIL
	$correo = $usr;
	$nombre = $name.' '.$name;
		
	$body = '<body><div><h2>Hello '.$name.' '.$last.'</h2><p>Please, <a href="http://malabaresdigitales.com/barber/php/chck_reg.php?usr='.$hashpass.'&email='.$usr.'">click here</a> to confirm your registration.</p></div></body>';
	$body = utf8_decode($body);
  $asunt = 'Confirm registration';
  $asunto = utf8_decode($asunt);
  //$fecha2 = strftime("%d / %B / %Y");
  $atencion = utf8_decode("Star's Edge Masters Barber Shop");
  $from = "noreply@malabaresdigitales.com";
  //—————————— SEND EMAIL ——————————————————.
  $mail = new PHPMailer(true);
  //$mail->SMTPDebug = 2;
  //$mail->isSMTP();
  //$mail->Host       = 'mail.ofipc.com.mx';
  //$mail->SMTPAuth   = true;
  //$mail->Username   = 'user@ofipc.com.mx';
  //$mail->Password   = 'mike6922?2017';
  //$mail->SMTPSecure = 'tls';
  //$mail->Port       = 1025;
  $mail->setFrom($from, $atencion);
  $mail->addAddress($correo, $nombre);
  $mail->addReplyTo($from, $atencion);
  $mail->isHTML(true);
  $mail->Subject = $asunto;
  $mail->Body    = $body;
  $mail->AltBody = 'Only HTML text';
  if($mail->Send()){
    echo 'exito';
  } else {
    echo 'error';
  }
  //————————————————————————————————————————.
}
?>