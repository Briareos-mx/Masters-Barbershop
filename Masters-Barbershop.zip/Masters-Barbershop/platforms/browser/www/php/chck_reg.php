<?php
session_start();
require_once ('conecta.php');
$hoy = date("Y-m-d");
$usr_key =  $_GET['usr'];
$usr_email = $_GET['email'];
$sql = 'UPDATE `registro` SET `registro` = "1", `fecha` = "'.$hoy.'", `activo` = "1" WHERE `pass`= "'.$usr_key.'" AND `usr`= "'.$usr_email.'"';
$consulta = mysqli_query($con,$sql);
$total = mysqli_affected_rows($con);
if($total < 1){
  echo '<h2>ERROR, PLEASE TRY AGAIN</h2>';
} else {
	echo '<h2>THANK YOU, ALREADY CONFIRM YOUR REGISTRATION, <a http://malabaresdigitales.com/barber/appointment.html>CLICK HERE</a> TO CONTINUE</h2>';
	//SEND CHECK MAIL
}
?>