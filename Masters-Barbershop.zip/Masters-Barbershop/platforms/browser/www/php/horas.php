<?php
session_start();
require_once ('conecta.php');
$ladata = '';
$sql = 'SELECT * FROM `horas`';
$consulta = mysqli_query($con,$sql);
while($row = mysqli_fetch_assoc($consulta)) {
  $cons = $row['h_cons'];
  $hora = $row['h_hora'];
  $ladata .= '<div class="col-6 mb-4">
              <button type="button" class="btn btn-secondary btn-block btn-hora" title="'.$cons.'">'.$hora.'</button>
            </div>';
}
echo ($ladata);
?>