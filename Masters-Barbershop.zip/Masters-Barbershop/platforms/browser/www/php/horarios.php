<?php
session_start();
require_once ('conecta.php');
//serv:serv, barb:barb, date:date
$servp = $_POST['serv'];//'hrct';//$_POST['serv'];//
$barbp = $_POST['barb'];//'bianey';//$_POST['barb'];//
$datep = $_POST['date'];//'24 December, 2020';//$_POST['date'];//
//echo 'SERVICIO: '.$servp.'<br>';
//echo 'BARBERO: '.$barbp.'<br>';
//echo 'FECHA: '.$datep.'<br>';
$lotrabajo = 0;
$fecha = date_create_from_format('j M, Y', $datep);//date('Y-m-d', strtotime($datep));
$buscafecha = date_format($fecha, 'Y-m-d');
$buscadia = date('w', strtotime($buscafecha));
//echo 'BUSCAFECHA: '.$buscafecha.'<br>';
//echo 'BUSCADIA: '.$buscadia.'<br>';



/*$fecha = date_create_from_format('j M, Y', $datep);
echo('<br>');
echo date_format($fecha, 'Y');
echo('<br>');*/




$data =[];

function check_in_range($start_date, $end_date, $date_from_user) {
  // Convert to timestamp
  $start_ts = strtotime($start_date);
  $end_ts = strtotime($end_date);
  $user_ts = strtotime($date_from_user);
  // Check that user date is between start & end
  return (($user_ts >= $start_ts) && ($user_ts <= $end_ts));
}

$sql = 'SELECT * FROM `calendar` WHERE `c_barber`= "'.$barbp.'" AND `c_day`= "'.$buscafecha.'"';
$consult = mysqli_query($con,$sql);
$num = mysqli_num_rows($consult);
if ($num < 1) {
  $sqlb = 'SELECT * FROM `barberos` WHERE `b_clave`= "'.$barbp.'" AND `b_active` = "1"';
  $consultb = mysqli_query($con,$sqlb);
  $rowb = mysqli_fetch_assoc($consultb);

  $b_clave = $rowb['b_clave'];
  $b_monday = $rowb['b_monday'];
  $b_tuesday = $rowb['b_tuesday'];
  $b_wednesday = $rowb['b_wednesday'];
  $b_thursday = $rowb['b_thursday'];
  $b_friday = $rowb['b_friday'];
  $b_saturday = $rowb['b_saturday'];
  $b_sunday = $rowb['b_sunday'];
  $b_holiday_start = $rowb['b_holiday_start'];
  $b_holiday_end = $rowb['b_holiday_end'];
  $b_time_start = $rowb['b_time_start'];
  $b_time_end = $rowb['b_time_end'];

  //HORAS QUE TRABAJA
  $ocho = $rowb['b_ocho'];
  $ocho5 = $rowb['b_ocho5'];
  $nueve = $rowb['b_nueve'];
  $nueve5 = $rowb['b_nueve5'];
  $diez = $rowb['b_diez'];
  $diez5 = $rowb['b_diez5'];
  $once = $rowb['b_once'];
  $once5 = $rowb['b_once5'];
  $doce = $rowb['b_doce'];
  $doce5 = $rowb['b_doce5'];
  $trece = $rowb['b_trece'];
  $trece5 = $rowb['b_trece5'];
  $catorce = $rowb['b_catorce'];
  $catorce5 = $rowb['b_catorce5'];
  $quince = $rowb['b_quince'];
  $quince5 = $rowb['b_quince5'];
  $dieciseis = $rowb['b_dieciseis'];
  $dieciseis5 = $rowb['b_dieciseis5'];
  $diecisiete = $rowb['b_diecisiete'];
  $diecisiete5 = $rowb['b_diecisiete5'];

  //ESTA DE VACACIONES
  $invacation = check_in_range($b_holiday_start, $b_holiday_end, $buscafecha);

  //DIAS QUE TRABAJA
  if ($buscadia == 0) {
    if ($b_sunday == 1){
      $lotrabajo = 1;
    }
  } else if ($buscadia == 1) {
    if ($b_monday == 1){
      $lotrabajo = 1;
    }
  } else if ($buscadia == 2) {
    if ($b_tuesday == 1){
      $lotrabajo = 1;
    }
  } else if ($buscadia == 3) {
    if ($b_wednesday == 1){
      $lotrabajo = 1;
    }
  } else if ($buscadia == 4) {
    if ($b_thursday == 1){
      $lotrabajo = 1;
    }
  } else if ($buscadia == 5) {
    if ($b_friday == 1){
      $lotrabajo = 1;
    }
  } else if ($buscadia == 6) {
    if ($b_saturday == 1){
      $lotrabajo = 1;
    }
  }
	if ($lotrabajo == 1) {
    if ($invacation == false) {
      $rowEmp = array('barber' => $b_clave, 'day' => $buscafecha, 'ocho' => $ocho, 'ocho5' => $ocho5, 'nueve' => $nueve, 'nueve5' => $nueve5, 'diez' => $diez, 'diez5' => $diez5, 'once' => $once, 'once5' => $once5, 'doce' => $doce, 'doce5' => $doce5, 'trece' => $trece, 'trece5' => $trece5, 'catorce' => $catorce, 'catorce5' => $catorce5, 'quince' => $quince, 'quince5' => $quince5, 'dieciseis' => $dieciseis, 'dieciseis5' => $dieciseis5, 'diecisiete' => $diecisiete, 'diecisiete5' => $diecisiete5);
      $data[] = array_map('htmlentities', $rowEmp);
    }
  }	
} else {
	$rowc = mysqli_fetch_assoc($consult);
    
  $barber = $rowc['c_barber'];
  $day = $rowc['c_day'];
  $ocho = $rowc['c_eight'];
  $ocho5 = $rowc['c_eight_half'];
  $nueve = $rowc['c_nine'];
  $nueve5 = $rowc['c_nine_half'];
  $diez  = $rowc['c_ten'];
  $diez5 = $rowc['c_ten_half'];
  $once  = $rowc['c_eleven'];
  $once5 = $rowc['c_eleven_half'];
  $doce = $rowc['c_twelve'];
  $doce5 = $rowc['c_twelve_half'];
  $trece = $rowc['c_thirteen'];
  $trece5 = $rowc['c_thirteen_half'];
  $catorce = $rowc['c_fourteen'];
  $catorce5 = $rowc['c_fourteen_half'];
  $quince = $rowc['c_fifteen'];
  $quince5 = $rowc['c_fifteen_half'];
  $dieciseis = $rowc['c_sixteen'];
  $dieciseis5 = $rowc['c_sixteen_half'];
  $diecisiete = $rowc['c_seventeen'];
  $diecisiete5 = $rowc['c_seventeen_half'];

  $rowEmp = array('barber' => $barber, 'day' => $buscafecha, 'ocho' => $ocho, 'ocho5' => $ocho5, 'nueve' => $nueve, 'nueve5' => $nueve5, 'diez' => $diez, 'diez5' => $diez5, 'once' => $once, 'once5' => $once5, 'doce' => $doce, 'doce5' => $doce5, 'trece' => $trece, 'trece5' => $trece5, 'catorce' => $catorce, 'catorce5' => $catorce5, 'quince' => $quince, 'quince5' => $quince5, 'dieciseis' => $dieciseis, 'dieciseis5' => $dieciseis5, 'diecisiete' => $diecisiete, 'diecisiete5' => $diecisiete5);
  $data[] = array_map('htmlentities', $rowEmp);
	
}
echo json_encode($data);

?>