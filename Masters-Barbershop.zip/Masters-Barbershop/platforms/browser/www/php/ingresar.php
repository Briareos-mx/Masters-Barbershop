<?php
session_start();
require_once ('conecta.php');
$usr = $_POST["usuario"];
$psw = $_POST["contra"];
$sql = 'SELECT * FROM `registro` WHERE `usr`="'.$usr.'"';
$consulta = mysqli_query($con,$sql);
$total = mysqli_num_rows($consulta);
if($total == 0){
    echo 'NoData';
} else {
	$row = mysqli_fetch_assoc($consulta);
	$clave		= $row['clave'];
	$pass			= $row['pass'];
	$usr			= $row['usr'];
	if(password_verify($psw, $pass)) {
		$_SESSION["clave"]	= $row['clave'];
		$_SESSION["pass"]		= $row['pass'];
		$_SESSION["usuario"]= $row['usr'];
		echo 'Confirmed';
	} else {
		session_unset();
		session_destroy();
		session_write_close();
		setcookie(session_name(),'',0,'/');
		session_regenerate_id(true);
		echo 'NoData';
	}
}
?>